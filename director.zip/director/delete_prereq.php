<?php
session_start();
include('../conn.php');
$id=$_GET['id'];
$p_id=$_SESSION['p_id'];
$run = mysqli_query($con, "SELECT * FROM `prerequisite` where `id`='".$id."' AND `p_id`='".$p_id."'");
$row = mysqli_fetch_assoc($run);
$name = $row['name'];

mysqli_query($con, "DELETE FROM `prerequisite` where `id`='".$id."' AND `p_id`='".$p_id."'");
mysqli_query($con, "DELETE FROM `completed_prereq` where `prereq_name`='".$name."' AND `p_id`='".$p_id."'");


header('location:list_of_prereq.php');

?>