<?php
session_start();
include ('../conn.php');
$id = $_GET['id'];
$p_id = $_SESSION['p_id'];
$x = "Met";
 
 mysqli_query($con, "UPDATE `student` SET `met/not-met`='".$x."' where `id`='".$id."' AND `p_id`='".$p_id."'");
header('location:stud_profile.php?id='.$id);

?>